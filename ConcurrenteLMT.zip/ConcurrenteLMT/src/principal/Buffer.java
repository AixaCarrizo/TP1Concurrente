package principal;
import java.lang.String;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.TimeUnit;

public class Buffer {
	Queue<String> cola;
	Buffer(){
		cola =new ConcurrentLinkedQueue<String>();
	}

public synchronized String remove() {	

	int rand = (int) Math.random()*60 + 10;
	
	try {
		TimeUnit.MILLISECONDS.sleep(rand);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	String aux = cola.poll();
	
	return aux;
 }

public void agregar(String e) {
	
	synchronized (this) {
		
		this.cola.add(e);		
		this.notifyAll();		
	}
}
public synchronized boolean EsVacia() {
	return this.cola.isEmpty();
}
public int size() {
	
	return cola.size();
}

}



