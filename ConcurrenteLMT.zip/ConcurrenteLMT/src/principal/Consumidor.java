package principal;

import java.util.concurrent.TimeUnit;

public class Consumidor extends Thread{
	
	int id;
	Buffer cola;
	
	public Consumidor(int id, Buffer cola) {
		
		this.id = id;
		this.cola = cola;
	}

	@Override
	public void run() {	
		
		while(true) {
				
			if(!cola.EsVacia()) {
				
				String aux = cola.remove();
				
				System.out.println("El consumidor " + id + " a consumido: " + aux);
				
			} 
		}
	}
}
