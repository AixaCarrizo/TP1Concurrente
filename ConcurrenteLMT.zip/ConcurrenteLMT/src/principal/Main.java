package principal;

public class Main {

	public static void main(String[] args) {
		
		Buffer buff = new Buffer();
		
		Thread task0 = new Thread(new Productor(0, buff));
		Thread task1 = new Thread(new Productor(1, buff));
		
		Thread task2 = new Thread(new Consumidor(0, buff));
		Thread task3 = new Thread(new Consumidor(1, buff));
		
		task0.start();
		task1.start();
		task2.start();
		task3.start();
	}

}
