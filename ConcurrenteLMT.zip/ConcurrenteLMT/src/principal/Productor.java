package principal;

import java.util.concurrent.TimeUnit;

public class Productor extends Thread{
	private int nroP;
	Buffer cola;
	int t;
	
Productor(int p, Buffer Cola) {
	 nroP =p;
	 t=0;
	 cola=Cola;
	
	}
/*
private void consumir(int t, Buffer cola) {
	for(int i=0; i<t; i++) {
	}
  }
*/


@Override
public void run() {
	
	while(t<100) {
		
		if(cola.size()<10) {
			
			String aux = nroP + " - " + t++;
			
			System.out.println("El productor " + nroP + " agrega el producto: " + aux);
			
			cola.agregar(aux);		
			
		} else System.out.println("El productor " + nroP + " pierde el producto: " + t++);
		
		int rand = (int) Math.random()*60 + 5;
		
		try {
			TimeUnit.MILLISECONDS.sleep(rand);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	
	
}

}


